package com.example.belozerovka_pr_31_02

import android.app.backup.SharedPreferencesBackupHelper
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.gson.Gson

class FristActivity : AppCompatActivity() {


    private lateinit var loginEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var sharedPreferences: SharedPreferences


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frist)

        loginEditText = findViewById(R.id.login)
        passwordEditText = findViewById(R.id.pass)
        loginButton = findViewById(R.id.button)
        sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE)


        val savedLogin = sharedPreferences.getString("login", null)
        val savedPassword = sharedPreferences.getString("password", null)

        if (savedLogin != null && savedPassword != null) {


            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
           Toast.makeText(this, "Вход выполнен", Toast.LENGTH_SHORT).show()
            }
        }

        fun REG(view: View) {
            val login = loginEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (login.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Введите логин и пароль", Toast.LENGTH_SHORT).show()
            } else {

                with(sharedPreferences.edit()) {
                    putString("login", login)
                    putString("password", password)
                    apply()
                }

                val intent = Intent(this@FristActivity, SecondActivity::class.java)
                startActivity(intent)


        }


    }


}