package com.example.belozerovka_pr_31_02

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast

class SecondActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var number: EditText
    private lateinit var spinnerFromUnit: Spinner
    private lateinit var spinnerToUnit: Spinner
    private val units = arrayOf("Байты", "Килобайты", "Мегабайты", "Гигабайты")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE)
            number = findViewById(R.id.Input)
        spinnerFromUnit = findViewById(R.id.From)
        spinnerToUnit = findViewById(R.id.In)


        val units = arrayOf("Байты", "Килобайты", "Мегабайты", "Гигабайты")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, units)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerFromUnit.adapter = adapter



        val adapter2 = ArrayAdapter(this, android.R.layout.simple_spinner_item, units)
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerToUnit.adapter = adapter2

    }

    fun result(view: View)
    {
        if(number.text.isEmpty())
            Toast.makeText(this, "Не введено число", Toast.LENGTH_SHORT).show()
        else {
            convertUnits()
        }

    }

    fun Logout(view: View) {

        with (sharedPreferences.edit()) {
            remove("login")
            remove("password")
            apply()
        }
        var intent = Intent(this, FristActivity::class.java)
        startActivity(intent)

    }

    private fun convertUnits() {
        val inputValue = number.text.toString().trim()

        val inputValueDouble = inputValue.toDoubleOrNull() ?: 0.0


        val fromUnitIndex = spinnerFromUnit.selectedItemPosition


        val toUnitIndex = spinnerToUnit.selectedItemPosition

        val fromUnit = units[fromUnitIndex]
        val toUnit = units[toUnitIndex]

        val result = when (fromUnit) {
            "Байты" -> inputValueDouble
            "Килобайты" -> inputValueDouble * 1024
            "Мегабайты" -> inputValueDouble * 1024 * 1024
            "Гигабайты" -> inputValueDouble * 1024 * 1024 * 1024
            else -> 0.0
        }


        val finalResult = when (toUnit) {
            "Байты" -> result
            "Килобайты" -> result / 1024
            "Мегабайты" -> result / (1024 * 1024)
            "Гигабайты" -> result / (1024 * 1024 * 1024)
            else -> 0.0
        }



        val intent = Intent(this, ThirdActivity::class.java)
        intent.putExtra("num",inputValueDouble)
        intent.putExtra("result", finalResult)
        startActivity(intent)
    }
}