import java.util.UUID

data class Crime(val id: UUID = UUID.randomUUID(), var isSolved: Boolean=true, var title: String="",var date:String="") {
}