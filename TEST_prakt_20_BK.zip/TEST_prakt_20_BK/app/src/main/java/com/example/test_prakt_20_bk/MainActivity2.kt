package com.example.test_prakt_20_bk

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.google.android.material.snackbar.Snackbar

class MainActivity2 : AppCompatActivity() {

    private lateinit var snackbar: Snackbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun BUT1(view: View)
    {
        Snackbar.make(view,"Prologistic.com.ua - программирование на Java | Android", Snackbar.LENGTH_LONG).show()


    }

    fun BUT2(view: View)
    {
        var snackbar=Snackbar.make(view,"Вы изменили что-то",Snackbar.LENGTH_LONG)
        snackbar.setAction("Next..", View.OnClickListener {  Snackbar.make(view,"Prologistic.com.ua - программирование на Java | Android", Snackbar.LENGTH_LONG).show()})




    }

    fun BUT3(view: View)
    {



    }
}