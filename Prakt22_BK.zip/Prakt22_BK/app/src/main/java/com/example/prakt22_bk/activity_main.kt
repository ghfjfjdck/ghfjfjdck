package com.example.prakt22_bk

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import androidx.compose.material3.Snackbar
import androidx.compose.ui.graphics.Color
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.snackbar.Snackbar
import org.json.JSONObject

class activity_main : AppCompatActivity() {

    private lateinit var city1:EditText
    private lateinit var rootView:View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
            rootView =findViewById(R.id.fraview)
        city1 = findViewById(R.id.editText)

    }


    fun GetResult(city:String){

        if(city.isNotEmpty()&& city!=null){

            var key="9802e006a8578c10d69fed8d11e8c622"
            var url = "https://api.openweathermap.org/data/2.5/weather?q="+city+"&appid="+key+"&units=metric&lang=ru"
            val queue = Volley.newRequestQueue(this)
            val stringRequest = StringRequest(

                Request.Method.GET,
                url,
                {
                    response ->
                    val obj = JSONObject(response)
                    val temp = obj.getJSONObject("weather")
                    Log.d("MyLog","Response: ${temp.getString("temp")}")
                },
                {
                    Log.d("MyLog","Volley error: $it")
                    Snackbar.make(rootView,"Ошибка",Snackbar.LENGTH_SHORT)
                }
            )
            queue.add(stringRequest)
        }
            else
        {
            var sn =Snackbar.make(rootView,"Пустое поле City", Snackbar.LENGTH_SHORT)
            sn.setActionTextColor(android.graphics.Color.RED)
            sn.show()
        }


    }

    fun FIND(view: View) {

        GetResult(city1.text.toString())


    }
}