package com.example.belozerovka_pr_31_02

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class ThirdActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var number: TextView
    private lateinit var Result: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)
        sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE)
                 number = findViewById(R.id.textView2)
                 Result = findViewById(R.id.pass)
        val result = intent.getDoubleExtra("result", 0.0)
        val num = intent.getDoubleExtra("num", 0.0)

        number.text="Вы ввели число : $num "
        Result.hint="Результат ${result.toInt()}"



    }

    fun Logout(view: View) {

        with (sharedPreferences.edit()) {
            remove("login")
            remove("password")
            apply()
        }
        var intent = Intent(this, FristActivity::class.java)
        startActivity(intent)
    }





}