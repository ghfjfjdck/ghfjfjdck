//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
try {
    var day1: DayofWeek = DayofWeek.Thursday;
    println("${day1.name} ${day1.ordinal}");
    var color: DayofWeek = DayofWeek.Red;
    println("${color.name} ${color.ordinal}");
}catch(e:Exception)
{
    println("Ошибка");

}

}