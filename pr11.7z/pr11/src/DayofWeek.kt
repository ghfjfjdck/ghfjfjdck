enum class DayofWeek(val value: Int) {
    Monday(1),
    Tuesday(2),
    Wednesday(3),
    Thursday(4),
    Friday(5),
    Saturday(6),
    Sunday(7),
    Red(8),
    Blue(9),
    Green(10),
    Yellow(11),
    Black(12),
    White(13);

}