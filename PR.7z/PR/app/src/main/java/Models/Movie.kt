package Models

class Movie (
    val id:Int,
    val movie:String,
    val rating:Double,
    val imdb_url:String,
)
