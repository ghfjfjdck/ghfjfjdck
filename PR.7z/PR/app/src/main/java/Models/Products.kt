package Models

class Product (val id:Int,val name:String)
