package layout

import java.util.UUID

data class Crime(val id:UUID = UUID.randomUUID(),var title:String =" ",val date: Any ="",var isSolved: Boolean=false) {



}