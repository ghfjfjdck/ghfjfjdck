package com.example.criminalintent

import CrimeFragment
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.crimefragment)

        val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
        if(currentFragment==null)
        {
            val fragment =CrimeFragment()
            supportFragmentManager.beginTransaction().add(R.id.fragment_container,fragment).commit()
        }





    }

    fun click(view: View) {}
}