package com.example.prakt22_bk

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.compose.material3.Snackbar
import androidx.compose.ui.graphics.Color
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.snackbar.Snackbar
import org.json.JSONException
import org.json.JSONObject

class activity_main : AppCompatActivity() {

    private lateinit var cityEditText: EditText
    private lateinit var getWeatherButton: Button
    private lateinit var weatherTextView: TextView
    private lateinit var temperatureTextView: TextView
    private lateinit var pressureTextView: TextView
    private lateinit var windSpeedTextView: TextView
    private lateinit var rootview: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Используйте ваше имя файла layout

        cityEditText = findViewById(R.id.cityEditText)
        getWeatherButton = findViewById(R.id.getWeatherButton)
        weatherTextView = findViewById(R.id.weatherTextView)
        temperatureTextView = findViewById(R.id.temperatureTextView)
        pressureTextView = findViewById(R.id.pressureTextView)
        windSpeedTextView = findViewById(R.id.windSpeedTextView)
                rootview = findViewById(R.id.framview)
        getWeatherButton.setOnClickListener {
            val city = cityEditText.text.toString()
            getWeatherData(city)
        }
    }

    private fun getWeatherData(city: String) {
        if (city.isNotEmpty()) {
            val apiKey = "9802e006a8578c10d69fed8d11e8c622"
            val url = "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric&lang=ru"

            val queue: RequestQueue = Volley.newRequestQueue(this)
            val stringRequest = StringRequest(
                Request.Method.GET,
                url,
                { response ->
                    try {
                        val jsonObject = JSONObject(response)
                        if (jsonObject.getString("cod") == "200") {
                            val weatherDescription = jsonObject.getJSONArray("weather")[0]as JSONObject
                            val weatherDescriptionText = weatherDescription.getString("description")
                            val mainObject = jsonObject.getJSONObject("main")
                            val temperature = mainObject.getString("temp")
                            val pressure = mainObject.getString("pressure")
                            val windSpeed = jsonObject.getJSONObject("wind").getString("speed")

                            weatherTextView.text = "Погода: $weatherDescriptionText"
                            temperatureTextView.text = "Температура: $temperature°C"
                            pressureTextView.text = "Давление: $pressure гПа"
                            windSpeedTextView.text = "Скорость ветра: $windSpeed м/с"
                        } else {

                            Log.e("MyLog", "Ошибка получения данных: ${jsonObject.getString("message")}")
                        }
                    } catch (e: JSONException) {

                        Log.e("MyLog", "Ошибка парсинга JSON", e)
                    }
                },
                {
                    Log.d("MyLog", "Volley error: $it")
                    Snackbar.make(rootview, "Ошибка", Snackbar.LENGTH_SHORT).show()
                }
            )
            queue.add(stringRequest)
        } else {
            Snackbar.make(rootview, "Пустое поле City", Snackbar.LENGTH_SHORT).show()
        }
    }
}